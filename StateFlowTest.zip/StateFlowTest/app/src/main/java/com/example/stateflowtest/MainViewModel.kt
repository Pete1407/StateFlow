package com.example.stateflowtest

import android.text.TextUtils
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val _loginUiState = MutableStateFlow<LoginUiState>(LoginUiState.Empty)

    sealed class LoginUiState {
        object Loading : LoginUiState()
        object Empty : LoginUiState()
        data class Success(val user: User) : LoginUiState()
        data class Error(val error: Throwable) : LoginUiState()
        data class InvalidInput(val message: String) : LoginUiState()

    }

    private var username : String? = null
    private var password : String? = null
    val text = "Username or Password should not be null"

    fun getLoginUiState() = _loginUiState

    fun logIn(usernameValue:String,passwordValue:String){
        viewModelScope.launch {
            _loginUiState.value = LoginUiState.Loading
            delay(3000L)
            if(TextUtils.isEmpty(username) && TextUtils.isEmpty(password)){
                _loginUiState.value = LoginUiState.InvalidInput(text)
            }else{
                if(usernameValue == username && passwordValue == password){
                    val user = User("1", username!!)
                    _loginUiState.value = LoginUiState.Success(user)
                }else{
                    val error = "Wrong credentials"
                    _loginUiState.value = LoginUiState.Error(Throwable(error))
                }
            }
        }
    }


}