package com.example.stateflowtest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.example.stateflowtest.databinding.ActivityMainBinding
import com.example.stateflowtest.MainViewModel.LoginUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect

class MainActivity : AppCompatActivity() {

    private val viewModel : MainViewModel by viewModels()
    private var _binding : ActivityMainBinding? = null
    private val binding
        get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setUI()
    }

    private fun setUI(){
        var bgDrawable = ContextCompat.getDrawable(this,R.drawable.ic_launcher_background)
        Log.i("result","intrinshicHeight --> ${bgDrawable!!.intrinsicHeight}")
        bgDrawable!!.intrinsicHeight
        binding.login.setOnClickListener {
            val usernameText = binding.username.text.toString()
            val passwordText = binding.password.text.toString()
            viewModel.logIn(usernameText,passwordText)
        }

        // lifecycle จะอยู่ใน activity, fragment จะถูกยกเลิกอัติโนมัติเมื่ออยู่ใน onDestroy
        // Activity use lifecycleowner
        // Fragment use viewlifecycleowner
        lifecycleScope.launchWhenCreated {
            //Log.i("result","when created")
        }

        lifecycleScope.launchWhenStarted{
            //Log.i("result","when started")
            viewModel.getLoginUiState().collect {
                renderUI(it)
            }
        }

        lifecycleScope.launchWhenResumed{
            viewModel.getLoginUiState().collect {
                renderUI(it)
            }
//            while(true){
//                Log.i("result","when resume")
//                delay(1000)
//            }

        }
    }

    private fun renderUI(uiState : LoginUiState){
        when(uiState){
            is LoginUiState.Empty ->{
                binding.currentState.text = "${getString(R.string.state)}: Empty"
                binding.progressBar.gone()
            }

            is LoginUiState.Loading ->{
                binding.currentState.text = "${getString(R.string.state)}: Loading"
                binding.progressBar.visibility()
            }
            is LoginUiState.InvalidInput ->{
                binding.progressBar.gone()
                binding.currentState.text = "${getString(R.string.state)}: InvalidInput"
            }
            is LoginUiState.Success ->{
                binding.progressBar.gone()
                binding.currentState.text = "${getString(R.string.state)}: Success --> ${uiState.user.username}"
            }
            is LoginUiState.Error ->{
                binding.progressBar.gone()
                binding.currentState.text = "${getString(R.string.state)}: Error"
            }

        }
    }

    override fun onStart() {
        super.onStart()
        //Log.i("result","onStart")
    }

    override fun onResume() {
        super.onResume()
        //Log.i("result","onResume")
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}