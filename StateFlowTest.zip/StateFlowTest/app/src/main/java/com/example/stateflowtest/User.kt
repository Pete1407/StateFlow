package com.example.stateflowtest

data class User(
    val id : String,
    val username : String
)
